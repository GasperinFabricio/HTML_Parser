
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Stack;

public class HtmlAnalyzer {
	public static class ParseException extends Exception {
		private static final long serialVersionUID = 1L;
		private String code;

		public static String UNCLOSED_TAG = "Unclosed tag";
		public static String UNOPENED_TAG = "Unopened tag";
		public static String INVALID_CLOSING_TAG = "Invalid closing tag";
		
	    public ParseException(String code, String message) {
	        super(message);
	        this.setCode(code);
	    }

	    public ParseException(String code, String message, Throwable cause) {
	        super(message, cause);
	        this.setCode(code);
	    }

	    public String getCode() {
	        return code;
	    }

	    public void setCode(String code) {
	        this.code = code;
	    }
	}
	
	public static class Parser {
		private enum TagType {
			OPEN, CLOSE;
		}

		private class Tag {
			String name;
			TagType type;

			private Tag(String name, TagType type) {
				this.name = name;
				this.type = type;
			}
		}

		private BufferedReader input;
		private int maxDepthLevel;
		private String maxDepthLine;
		private Stack<String> tagStack;

		public String getMaxDepthLine() {
			return this.maxDepthLine;
		}

		public Parser(BufferedReader input) {
			this.input = input;
			// Set maxDepthLevel to -1 so that tagStack.size() > maxDepthlevel even if the
			// stack is empty.
			this.maxDepthLevel = -1;
			this.maxDepthLine = "";
			this.tagStack = new Stack<String>();
		}

		private Tag parseTag(String input) {
			String name;
			// Extracts tag name or returns null.
			if (input.startsWith("</")) {
				name = input.substring(2, input.length() - 1);
				return new Tag(name, TagType.CLOSE);
			} else if (input.startsWith("<")) {
				name = input.substring(1, input.length() - 1);
				return new Tag(name, TagType.OPEN);
			} else {
				return null;
			}
		}

		private void processTag(Tag currentTag) throws ParseException {
			String lastTagName;
			// Checking if it is an open or closing tag
			switch (currentTag.type) {
			case OPEN:
				tagStack.push(currentTag.name);
				break;
			case CLOSE:
				// If the stack is empty there is an unclosed tag within the HTML
				if (tagStack.isEmpty()) {
					throw new ParseException(ParseException.UNCLOSED_TAG, "Unclosed tag within HTML");
				}
				lastTagName = tagStack.pop();
				// If the current tag is different than the last one to be inserted it is a
				// malformed HTML
				if (!lastTagName.equals(currentTag.name)) {
					throw new ParseException(ParseException.INVALID_CLOSING_TAG,
							String.format("Expected closing tag %s but received %s", lastTagName, currentTag.name));
				}
				break;
			}

		}

		public void parse() throws IOException, ParseException {
			String currentLine = this.input.readLine();
			while (currentLine != null) {
				// Strip leading whitespaces
				if (currentLine != null) {
					currentLine = currentLine.stripLeading();
				}
				// If it reaches a new max depth store currentLine
				if (tagStack.size() > this.maxDepthLevel) {
					this.maxDepthLevel++;
					this.maxDepthLine = currentLine;
				}

				// Try parsing a tag from the currentLine
				Tag currentTag = parseTag(currentLine);
				if (currentTag != null) {
					processTag(currentTag);
				}
				currentLine = this.input.readLine();
			}
		}

	}
		public static void main(String[] args) {
			String url_address = args[0];
			BufferedReader content = null;
			HttpURLConnection connection = null;
			try {
				URL url = new URL(url_address);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestMethod("GET");
				int status = connection.getResponseCode();
				if (status == 404) {
					throw new Exception();
				}
				content = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			} catch (Exception e) {
				// e.printStackTrace();
				System.err.println("URL connection error");
			}

			// This should never happen
			if (content == null) {
				System.err.println("URL connection error");
			}

			Parser parser = new Parser(content);

			try {
				parser.parse();
			} catch (Exception e) {
				System.err.println("malformed HTML");
			}

			System.out.println(parser.getMaxDepthLine());
			try {
				connection.disconnect();
			} catch (Exception e) {

			}
		}
}
